1. Used Kong OIDC plugin version:

2. Used Kong version:

3. Kong OIDC plugin configuration:

4. Used OIDC provider:

5. Issue description:
